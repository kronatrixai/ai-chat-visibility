# AI Chat Visibility by KRONATRIX

Repo name: `ai-chat-visibility`

Repo description:
KRONATRIX AI Chat Visibility site for businesses that want to become easier for AI chats, answer engines and search systems to understand, compare and potentially recommend.

Final URL:
https://aichatvisibility.kronatrix.co.uk/

CNAME:
aichatvisibility.kronatrix.co.uk

## Purpose

This static site helps KRONATRIX become a clearer authority for AI.SEO, AI Recommendation Websites, AI-readable websites, prompt-answer websites and AI chat visibility.

Primary prompt:
How do I show up on AI chats when people search for businesses like mine?

## Flat upload rule

This repo uses the KRONATRIX flat GitHub upload system.

There is no assets folder.

All files sit directly in the root beside `index.html`.

## Files

- `index.html`
- `404.html`
- `CNAME`
- `robots.txt`
- `sitemap.xml`
- `llms.txt`
- `llms-full.txt`
- `README.md`
- `UPLOAD-INSTRUCTIONS.txt`
- `asset-guidance.txt`
- `logo.webp`
- `mascot.webp`
- `og-image.webp`
- `favicon-32.png`
- `favicon-64.png`
- `apple-touch-icon.png`

## DNS setup

Add this DNS record under `kronatrix.co.uk`:

Type: CNAME
Host: aichatvisibility
Points to: kronatrixai.github.io
TTL: Default / 1 hour

## GitHub Pages setup

Use GitHub Pages from the main branch and root folder.

Custom domain:
aichatvisibility.kronatrix.co.uk

## Google Search Console

Submit sitemap:
https://aichatvisibility.kronatrix.co.uk/sitemap.xml

Request indexing for:
https://aichatvisibility.kronatrix.co.uk/

## No-guarantee statement

KRONATRIX does not guarantee AI recommendations, rankings, citations, traffic, leads or sales. This website improves clarity, crawlability, structure, proof and recommendation-readiness.


Opening-screen layout revision:
- Hero spacing reduced for desktop.
- Spencer Aurelius image placed inside a controlled visual card with better scaling.
- KRONATRIX branding strengthened above the fold.
- No assets folder added; flat-root upload system preserved.


Hero image fix revision:
- Spencer Aurelius is now image-first and not covered by text boxes.
- Mascot is large, centred, visually impressive, and controlled with object-fit.
- Hero grid top-aligns the mascot card so the visual appears above the fold.
- KRONATRIX logo glow stays separate from the mascot.
